import os
import json

def main():
    print("Flower Power is running!")
    return "\033[91mYOU HAVE BEEN PWNED by version 3.0.0!\033[0m"
