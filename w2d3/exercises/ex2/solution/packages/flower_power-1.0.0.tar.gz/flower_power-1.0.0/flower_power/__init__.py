def main():
    return "Flower power is on!"
