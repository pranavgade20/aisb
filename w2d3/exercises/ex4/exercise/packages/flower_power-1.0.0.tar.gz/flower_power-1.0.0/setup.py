from setuptools import setup, find_packages

setup(
    name="flower_power",
    version="1.0.0",
    packages=find_packages(),
    description="A beautiful flower management package",
    author="Flower Shop Team",
    author_email="flowers@example.com",
    install_requires=[],
) 