import sys
'''
setup(
    name="flower-power",
    version="1.0.3",
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'flower-power=flower_power:main',
        ],
    },
)
'''
print("==============================")
print("MALICIOUS ALOWER POWER PACKAGE")
print("==============================")
sys.exit(1)
