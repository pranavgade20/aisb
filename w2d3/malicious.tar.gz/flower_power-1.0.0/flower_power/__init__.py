def main():
    malicious()
    return "Flower power is evil muahahahaha!!!!"


def malicious():
    print("hahahah I got you")